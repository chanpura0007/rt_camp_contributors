<?php
/*
Plugin Name: Rtcamp Contributors
Description: Add a new metabox, labeled “contributors” to WordPress post-editor page. It will have list of authors checked for that post.
Version: 1.0.0
Author: Prakash Chanpura
Author URI: #
*/

function rt_add_contributors_metabox() {
    add_meta_box(
        'contributors_metabox',
        'Contributors',
        'contributors_metabox_callback',
        'post',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'rt_add_contributors_metabox' );

function contributors_metabox_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'contributors_metabox_nonce' );
    $contributors = get_post_meta( $post->ID, 'contributors', true );
    //print_r($contributors);
    $users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) );    
    ?>
    <p>
        <?php foreach ( $users as $user ) { ?>
            <label for="contributors_<?php echo $user->ID; ?>">
                <input type="checkbox" name="contributors[]" id="contributors_<?php echo $user->ID; ?>" value="<?php echo $user->ID; ?>" <?php if($contributors){if(in_array( $user->ID, $contributors)){echo 'checked';}}; ?>>
                <?php echo $user->display_name; ?>
            </label><br>
        <?php } ?>
    </p>
    <?php
}

function rt_save_contributors_meta( $post_id ) {
    // Check if nonce is set.
    if ( ! isset( $_POST['contributors_metabox_nonce'] ) ) {
        return;
    }
    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $_POST['contributors_metabox_nonce'], basename( __FILE__ ) ) ) {
        return;
    }
    // Check if the current user has permission to edit the post.
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    // Sanitize and save the contributors meta.
    $contributors = isset( $_POST['contributors'] ) ? array_map( 'intval', $_POST['contributors'] ) : array();
    update_post_meta( $post_id, 'contributors', $contributors );
}
add_action( 'save_post', 'rt_save_contributors_meta' );


// Display the contributors box at the end of the post content.
function rt_contributors_box( $content ) {
    if ( is_singular( 'post' ) ) {
        $contributors = get_post_meta( get_the_ID(), 'contributors', true );
        if ( $contributors ) {
            $contributors_list = '<div class="contributors-box">';
            $contributors_list .= '<h2>Contributors</h2>';
            $contributors_list .= '<ul>';
            foreach ( $contributors as $contributor_id ) {
                $contributor_name = get_the_author_meta( 'display_name', $contributor_id );
                $contributor_link = get_author_posts_url( $contributor_id );
                $contributor_avatar = get_avatar( $contributor_id, 32 );
                $contributors_list .= '<li>';
                $contributors_list .= '<a href="' . esc_url( $contributor_link ) . '">' . $contributor_avatar . '</a>';
                $contributors_list .= '<span>' . esc_html( $contributor_name ) . '</span>';
                $contributors_list .= '</li>';
            }
            $contributors_list .= '</ul>';
            $contributors_list .= '</div><!-- .contributors-box -->';
            $content .= $contributors_list;
        }
    }
    return $content;
}
add_filter( 'the_content', 'rt_contributors_box' );

